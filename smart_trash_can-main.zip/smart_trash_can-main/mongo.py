import base64
from PIL import Image
from io import BytesIO
import pymongo


client = pymongo.MongoClient("mongodb+srv://suhashrdj:Suhashrdj@cluster0.xxcyb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client["SmartTrashCan"]
collection = db["WasteImages"]


latest_document = collection.find_one({}, sort=[("timestamp", -1)])

if latest_document:
    img_data = latest_document["image"]
    img_binary = base64.b64decode(img_data)
    
    
    image = Image.open(BytesIO(img_binary))
    image.show()
