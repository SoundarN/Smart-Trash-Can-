import pymongo


client = pymongo.MongoClient("mongodb+srv://suhashrdj:Suhashrdj@cluster0.xxcyb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")


db = client["SmartTrashCan"]


collection = db["WasteImages"]


sample_data = {
    "timestamp": "2025-02-04T12:34:56",
    "classification": "Recyclable",
    "confidence": 0.98,
    "image": None  
}

collection.insert_one(sample_data)

print("MongoDB Database and Collection Created Successfully! 🎉")
