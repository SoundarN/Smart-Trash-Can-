# 🗑️ Smart Trash Can: Waste Classification & Management

A deep learning based project that classifies waste into **Recyclable**, **Non-Recyclable**, or **Hazardous**, and automates waste sorting using image analysis, MongoDB for storage, and ESP32 for hardware control.

---

## Features

- **Real-Time Waste Classification** using TensorFlow and MobileNetV2.
- **Camera Integration**: Capture images from a webcam in real time.
- **Efficient Dataset Preparation** using `splitfolders`.
- **MongoDB Integration**: Stores image data, classification result, timestamp, and confidence.
- **Serial Communication**: Controls hardware (like ESP32) to automate physical sorting.
- **Visualization**: Shows classification result on the image desktop window.

---

## Project Structure

- `train_model.py` - Model training script (`MobileNetV2`, Keras/TensorFlow).
- `smart_trash_can.py` - Main logic: capture image, classify, send commands, and store results in MongoDB.
- `setup_mongodb.py` - Ensures MongoDB database and collection are ready.
- `mongo.py` - Retrieval and display of stored images from MongoDB.
- `DATASET/` - Raw waste images.
- `DATASET_SPLIT/` - Processed training/validation split (auto-created).

---

## Requirements

- Python 3.7+
- TensorFlow, Keras
- OpenCV (`cv2`)
- NumPy
- PyMongo
- splitfolders
- Pillow
- ESP32 (for hardware integration)

**To install dependencies:**
pip install tensorflow opencv-python numpy pymongo split-folders pillow

text

---

## Usage

### 1. Train the Model

python train_model.py

text

This saves `waste_classification_model.h5` in your project folder.

### 2. Run the Smart Trash Can

python smart_trash_can.py

text
- Press `SPACE` to capture an image, or `ESC` to exit.
- The application classifies the waste and sends a command to the ESP32 based on result.

### 3. Manage Data in MongoDB

python setup_mongodb.py # Initialize MongoDB collection/database
python mongo.py # Display latest waste image from database

text

---

## Hardware Integration

- Connect and configure an ESP32 board.
- Adjust `serial.Serial` port in `smart_trash_can.py` as needed (`COM8`, etc).
- Serial commands (1, 2, 3) are sent to ESP32 for sorting based on classification.

---

## Notes

- Make sure MongoDB is accessible with correct credentials.
- Ensure your webcam is working and accessible by OpenCV.
- Large datasets may be required to get best classification performance.

---

## License

This project is open-source for non-commercial and educational use.

---

**Let's make waste sorting easier and smarter! 🚮**