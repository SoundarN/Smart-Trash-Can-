import cv2
import numpy as np
import tensorflow as tf
import pymongo
import datetime
import os
import base64  
import serial
import time

client = pymongo.MongoClient("mongodb+srv://suhashrdj:Suhashrdj@cluster0.xxcyb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client["SmartTrashCan"]
collection = db["WasteImages"]


model = tf.keras.models.load_model("waste_classification_model.h5")

# Initialize serial connection to ESP32 (adjust COM port as needed)
try:
    ser = serial.Serial('COM8', 115200, timeout=1)  
    time.sleep(2)  # Allow ESP32 to reset
except Exception as e:
    ser = None
    print(f"⚠️ Serial connection failed: {e}")



CLASS_LABELS = ["Hazardous", "Non-Recyclable", "Recyclable"]


def capture_and_classify():
    cap = cv2.VideoCapture(0)  
    
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return None
    
    print("Press 'SPACE' to capture image or 'ESC' to exit.")
    
    while True:
        ret, frame = cap.read()  
        if not ret:
            print("Error: Could not read frame.")
            break
        
        cv2.imshow("Smart Trash Can - Live Feed", frame)  
        
        key = cv2.waitKey(1) & 0xFF
        
        if key == 27:  
            cap.release()
            cv2.destroyAllWindows()
            return None
        elif key == 32:  
            image_path = "captured_waste.jpg"
            cv2.imwrite(image_path, frame)  
            print(f"Image captured: {image_path}")
            
            cap.release()
            cv2.destroyAllWindows()
            return image_path  


def classify_waste(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (224, 224))  
    img = np.expand_dims(img, axis=0)  
    img = img / 255.0  


    predictions = model.predict(img)
    class_index = np.argmax(predictions)
    confidence = predictions[0][class_index]

    classification_result = CLASS_LABELS[class_index]

    print(f"Classification: {classification_result} ({confidence*100:.2f}%)")

    
    store_in_mongodb(image_path, classification_result, confidence)


    return classification_result, confidence  

def send_serial_command(value):
    if ser:
        try:
            ser.write(str(value).encode())
            print(f"✅ Sent serial value: {value}")
            time.sleep(6)  # Wait for ESP32 to process
        except Exception as e:
            print("❌ Serial communication error:", e)
    else:
        print("⚠️ Serial not available")


def store_in_mongodb(image_path, classification, confidence):
    try:
        with open(image_path, "rb") as img_file:
            img_binary = img_file.read()
            img_base64 = base64.b64encode(img_binary).decode("utf-8")

        document = {
            "timestamp": datetime.datetime.now(),
            "classification": classification,
            "confidence": float(confidence),  
            "image": img_base64
        }

        result = collection.insert_one(document)
        print(f"✅ Stored in MongoDB: {classification} ({confidence*100:.2f}%) | Inserted ID: {result.inserted_id}")

    except Exception as e:
        print(f"❌ MongoDB Insert Error: {e}")




if __name__ == "__main__":
    print("Detecting Waste...")
    image_path = capture_and_classify()
    
    if image_path:
        print("Processing Image for Classification...")
        classification, confidence = classify_waste(image_path)

        # Send serial command based on classification
        if classification == "Recyclable":
            send_serial_command(1)
        elif classification == "Non-Recyclable":
            send_serial_command(2)
        elif classification == "Hazardous":
            send_serial_command(3)

        # Display the image with result
        img = cv2.imread(image_path)
        cv2.putText(img, f"{classification} ({confidence*100:.2f}%)", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.imshow("Waste Classification", img)
        cv2.waitKey(3000)
        cv2.destroyAllWindows()

        os.remove(image_path)
    else:
        print("❌ Failed to capture image")

