import base64
import cv2
import numpy as np
import pymongo

# MongoDB Connection
client = pymongo.MongoClient("mongodb+srv://suhashrdj:Suhashrdj@cluster0.xxcyb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client["SmartTrashCan"]
collection = db["WasteImages"]

def retrieve_image_from_mongodb():
    document = collection.find_one(sort=[("timestamp", pymongo.DESCENDING)])  # Get the latest image entry
    if document:
        img_base64 = document["image"]
        img_binary = base64.b64decode(img_base64)
        nparr = np.frombuffer(img_binary, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        # Display the retrieved image
        cv2.imshow("Retrieved Waste Image", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        print("No image found in MongoDB.")

if __name__ == "__main__":
    retrieve_image_from_mongodb()
