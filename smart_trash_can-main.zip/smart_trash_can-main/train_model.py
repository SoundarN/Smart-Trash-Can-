import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.optimizers.legacy import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import os
import shutil
import splitfolders 

DATASET_PATH = "D:/final year project/project_trashcan/DATASET"  
PROCESSED_DATASET_PATH = "DATASET_SPLIT"  


if not os.path.exists(PROCESSED_DATASET_PATH):
    splitfolders.ratio(DATASET_PATH, output=PROCESSED_DATASET_PATH, seed=42, ratio=(0.8, 0.2), group_prefix=None)

TRAIN_PATH = os.path.join(PROCESSED_DATASET_PATH, "train")
VAL_PATH = os.path.join(PROCESSED_DATASET_PATH, "val")

base_model = MobileNetV2(weights="imagenet", include_top=False, input_shape=(224, 224, 3))


for layer in base_model.layers[-30:]:
    layer.trainable = True


x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(128, activation="relu")(x)  
output_layer = Dense(3, activation="softmax")(x) 


model = Model(inputs=base_model.input, outputs=output_layer)
optimizer = Adam(learning_rate=1e-4, decay=1e-6)
model.compile(optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"])


train_datagen = ImageDataGenerator(
    rescale=1.0 / 255,
    rotation_range=30,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.3,
    horizontal_flip=True,
    fill_mode="nearest"
)

val_datagen = ImageDataGenerator(rescale=1.0 / 255)


train_generator = train_datagen.flow_from_directory(
    TRAIN_PATH, target_size=(224, 224), batch_size=32, class_mode="categorical"
)
val_generator = val_datagen.flow_from_directory(
    VAL_PATH, target_size=(224, 224), batch_size=32, class_mode="categorical"
)


early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True, verbose=1)
lr_scheduler = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6, verbose=1)
model_checkpoint = ModelCheckpoint("best_waste_classification_model.h5", save_best_only=True, monitor="val_loss", verbose=1)


model.fit(
    train_generator,
    validation_data=val_generator,
    epochs=50,
    callbacks=[early_stopping, lr_scheduler, model_checkpoint]
)


model.save("waste_classification_model.h5")
print("✅ Model training completed and saved successfully.")
