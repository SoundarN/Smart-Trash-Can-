import pymongo

client = pymongo.MongoClient("mongodb://127.0.0.1:27017/")
db = client["SmarttrashCan"]
collection = db["WasteImages"]

print("✅ Connected to MongoDB!")

# Insert test document
result = collection.insert_one({
    "test": "MongoDB Connection Check"
})
print(f"✅ Test insert successful! Inserted ID: {result.inserted_id}")

# Retrieve test document
print("📝 Checking inserted document:")
for doc in collection.find():
    print(doc)
